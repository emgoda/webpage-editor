import React, { useState } from 'react';
import PageHierarchy from '../components/PageHierarchy';
import { ContainerRenderer } from '../components/ContainerRenderer';
import { useProjects, Container } from '../ProjectContext';

export default function EditorPage() {
  const { projects, addProject } = useProjects();
  const project = projects[0];
  const page = project.pages.find(p => p.isHome)!;
  const [selectedId, setSelectedId] = useState(page.containers[0].id);

  function findContainer(items: Container[], id: string): Container | null {
    for (const c of items) {
      if (c.id === id) return c;
      const found = findContainer(c.children, id);
      if (found) return found;
    }
    return null;
  }

  function update() {
    addProject({ ...project, pages: project.pages });
  }

  function handleAdd() {
    const parent = findContainer(page.containers, selectedId);
    if (!parent) return;
    const newNode: Container = {
      id: `c_${Date.now()}`,
      tag: 'div',
      props: {},
      children: [],
      content: '<p>New Container</p>'
    };
    parent.children.push(newNode);
    update();
  }

  function handleDelete() {
    function remove(items: Container[]): Container[] {
      return items.filter(c => c.id !== selectedId)
        .map(c => ({ ...c, children: remove(c.children) }));
    }
    page.containers = remove(page.containers);
    setSelectedId(page.containers[0]?.id || '');
    update();
  }

  const sel = findContainer(page.containers, selectedId)!;

  return (
    <div className="flex h-screen">
      <div className="w-1/5 p-4 border-r overflow-auto">
        <button onClick={handleAdd} className="btn btn-sm mb-2">Add</button>
        <button onClick={handleDelete} className="btn btn-sm mb-4">Delete</button>
        <PageHierarchy containers={page.containers} onSelect={setSelectedId} />
      </div>
      <div className="w-3/5 p-4 overflow-auto">
        <ContainerRenderer container={{ id: 'root', tag: 'div', props: {}, children: page.containers, content: '' }}
          selectedId={selectedId} onSelect={setSelectedId} />
      </div>
      <div className="w-1/5 p-4 border-l overflow-auto">
        <h3>Properties</h3>
        <label>Content</label>
        <textarea className="w-full mb-2 p-1" value={sel.content} onChange={e => { sel.content = e.target.value; update(); }} />
        <label>Style JSON</label>
        <textarea className="w-full p-1" value={JSON.stringify(sel.props.style||{}, null,2)}
          onChange={e => { try { sel.props.style = JSON.parse(e.target.value); update(); } catch {} }} />
      </div>
    </div>
  );
}