import React from 'react';
import EditorPage from './pages/EditorPage';
import { ProjectProvider } from './ProjectContext';

export default function App() {
  return (
    <ProjectProvider>
      <EditorPage />
    </ProjectProvider>
  );
}