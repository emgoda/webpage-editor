import React from 'react';
import { Container } from '../ProjectContext';

interface Props {
  container: Container;
  selectedId: string;
  onSelect: (id: string) => void;
}

export function ContainerRenderer({ container, selectedId, onSelect }: Props) {
  const isSelected = container.id === selectedId;
  return (
    <div style={{
      border: isSelected ? '2px solid #1890ff' : '1px dashed #ccc',
      padding: 8, margin: 4
    }} onClick={e => { e.stopPropagation(); onSelect(container.id); }}>
      {container.children.length > 0 ? container.children.map(c => (
        <ContainerRenderer key={c.id} container={c} selectedId={selectedId} onSelect={onSelect} />
      )) : <div dangerouslySetInnerHTML={{ __html: container.content }} />}
    </div>
  );
}