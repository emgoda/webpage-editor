import React from 'react';
import { Tree } from 'antd';
import { Container } from '../ProjectContext';

interface Props {
  containers: Container[];
  onSelect: (id: string) => void;
}

export default function PageHierarchy({ containers, onSelect }: Props) {
  const toTreeData = (items: Container[]): any[] =>
    items.map(c => ({
      title: `${c.tag} [${c.id}]`,
      key: c.id,
      children: toTreeData(c.children),
    }));
  return <Tree defaultExpandAll treeData={toTreeData(containers)} onSelect={(_, info) => onSelect(info.node.key as string)} />;
}