import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Container {
  id: string;
  tag: string;
  props: Record<string, any>;
  children: Container[];
  content: string;
}

export interface Page {
  pageId: string;
  remark: string;
  isHome: boolean;
  containers: Container[];
}

export interface Project {
  id: string;
  url: string;
  description: string;
  pages: Page[];
}

interface ContextType {
  projects: Project[];
  addProject: (proj: Omit<Project, 'pages'> & { pages?: Page[] }) => boolean;
}

const ProjectContext = createContext<ContextType>({
  projects: [],
  addProject: () => false,
});

export const useProjects = () => useContext(ProjectContext);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('projects');
    if (saved) setProjects(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('projects', JSON.stringify(projects));
  }, [projects]);

  const addProject = (proj: Omit<Project, 'pages'> & { pages?: Page[] }) => {
    if (projects.some(p => p.id === proj.id)) return false;
    const newProj: Project = {
      ...proj,
      pages: proj.pages || [{
        pageId: proj.id,
        remark: proj.description,
        isHome: true,
        containers: [{
          id: `c_${Date.now()}`,
          tag: 'div',
          props: {},
          children: [],
          content: '<p>Start editing...</p>'
        }]
      }]
    };
    setProjects([...projects, newProj]);
    return true;
  };

  return (
    <ProjectContext.Provider value={{ projects, addProject }}>
      {children}
    </ProjectContext.Provider>
  );
}